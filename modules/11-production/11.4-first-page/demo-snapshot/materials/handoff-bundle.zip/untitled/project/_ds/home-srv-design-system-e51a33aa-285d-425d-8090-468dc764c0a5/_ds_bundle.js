/* @ds-bundle: {"format":4,"namespace":"HomeSrvDesignSystem_e51a33","components":[{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"Card","sourcePath":"components/card/Card.jsx"},{"name":"CardHeader","sourcePath":"components/card/Card.jsx"},{"name":"CardTitle","sourcePath":"components/card/Card.jsx"},{"name":"CardDescription","sourcePath":"components/card/Card.jsx"},{"name":"CardAction","sourcePath":"components/card/Card.jsx"},{"name":"CardContent","sourcePath":"components/card/Card.jsx"},{"name":"CardFooter","sourcePath":"components/card/Card.jsx"},{"name":"ServiceCard","sourcePath":"components/service/ServiceCard.jsx"},{"name":"STATUS_META","sourcePath":"components/status/StatusBadge.jsx"},{"name":"StatusBadge","sourcePath":"components/status/StatusBadge.jsx"}],"sourceHashes":{"components/buttons/Button.jsx":"a505cb77da8c","components/card/Card.jsx":"8378ef918510","components/service/ServiceCard.jsx":"a4c247cb7109","components/status/StatusBadge.jsx":"3ea3349ceddc","ui_kits/monitor/Monitor.jsx":"4bc95642cfac"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.HomeSrvDesignSystem_e51a33 = window.HomeSrvDesignSystem_e51a33 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * home-srv Button — base-nova style, translated to plain CSS-variable styling.
 * Magenta primary, hairline outline, quiet ghost. 1px active nudge.
 */

const RADIUS = "var(--radius-lg)";
const SIZES = {
  xs: {
    height: 24,
    padding: "0 8px",
    fontSize: 12,
    gap: 4,
    radius: "var(--radius-md)"
  },
  sm: {
    height: 28,
    padding: "0 10px",
    fontSize: 12.8,
    gap: 4,
    radius: "var(--radius-md)"
  },
  default: {
    height: 32,
    padding: "0 10px",
    fontSize: 14,
    gap: 6,
    radius: RADIUS
  },
  lg: {
    height: 36,
    padding: "0 10px",
    fontSize: 14,
    gap: 6,
    radius: RADIUS
  },
  icon: {
    height: 32,
    width: 32,
    padding: 0,
    fontSize: 14,
    gap: 0,
    radius: RADIUS
  },
  "icon-sm": {
    height: 28,
    width: 28,
    padding: 0,
    fontSize: 13,
    gap: 0,
    radius: "var(--radius-md)"
  },
  "icon-lg": {
    height: 36,
    width: 36,
    padding: 0,
    fontSize: 14,
    gap: 0,
    radius: RADIUS
  }
};
const VARIANTS = {
  default: {
    base: {
      background: "var(--primary)",
      color: "var(--primary-foreground)",
      border: "1px solid transparent"
    },
    hover: {
      background: "color-mix(in oklch, var(--primary), transparent 20%)"
    }
  },
  outline: {
    base: {
      background: "color-mix(in oklch, var(--input), transparent 70%)",
      color: "var(--foreground)",
      border: "1px solid var(--input)"
    },
    hover: {
      background: "color-mix(in oklch, var(--input), transparent 50%)"
    }
  },
  secondary: {
    base: {
      background: "var(--secondary)",
      color: "var(--secondary-foreground)",
      border: "1px solid transparent"
    },
    hover: {
      background: "color-mix(in oklch, var(--secondary), var(--foreground) 5%)"
    }
  },
  ghost: {
    base: {
      background: "transparent",
      color: "var(--foreground)",
      border: "1px solid transparent"
    },
    hover: {
      background: "color-mix(in oklch, var(--muted), transparent 50%)"
    }
  },
  destructive: {
    base: {
      background: "color-mix(in oklch, var(--destructive), transparent 80%)",
      color: "var(--destructive)",
      border: "1px solid transparent"
    },
    hover: {
      background: "color-mix(in oklch, var(--destructive), transparent 70%)"
    }
  },
  link: {
    base: {
      background: "transparent",
      color: "var(--primary)",
      border: "1px solid transparent",
      textUnderlineOffset: "4px"
    },
    hover: {
      textDecoration: "underline"
    }
  }
};
function Button({
  variant = "default",
  size = "default",
  disabled = false,
  className = "",
  style = {},
  children,
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const s = SIZES[size] || SIZES.default;
  const v = VARIANTS[variant] || VARIANTS.default;
  const composed = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    whiteSpace: "nowrap",
    userSelect: "none",
    cursor: disabled ? "not-allowed" : "pointer",
    fontFamily: "var(--font-sans)",
    fontWeight: "var(--weight-medium)",
    fontSize: s.fontSize,
    gap: s.gap,
    height: s.height,
    width: s.width,
    padding: s.padding,
    borderRadius: s.radius,
    transition: "background 140ms ease, border-color 140ms ease, transform 60ms ease",
    outline: "none",
    opacity: disabled ? 0.5 : 1,
    transform: active && !disabled ? "translateY(1px)" : "none",
    ...v.base,
    ...(hover && !disabled ? v.hover : null),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    className: className,
    style: composed,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false)
  }, props), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/card/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * home-srv Card family — base-nova. A raised surface with a hairline ring
 * (not a heavy shadow). Spacing driven by a --card-spacing local var.
 */

const SPACING = {
  default: 16,
  sm: 12
};
function Card({
  size = "default",
  className = "",
  style = {},
  children,
  ...props
}) {
  const pad = SPACING[size] || SPACING.default;
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card",
    className: className,
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      gap: pad,
      overflow: "hidden",
      borderRadius: "var(--radius-xl)",
      background: "var(--card)",
      color: "var(--card-foreground)",
      fontSize: "var(--text-sm)",
      fontFamily: "var(--font-sans)",
      paddingTop: pad,
      paddingBottom: pad,
      boxShadow: "inset 0 0 0 1px color-mix(in oklch, var(--foreground), transparent 90%)",
      "--card-spacing": pad + "px",
      ...style
    }
  }, props), children);
}
function CardHeader({
  className = "",
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-header",
    className: className,
    style: {
      display: "grid",
      gap: 4,
      paddingLeft: "var(--card-spacing, 16px)",
      paddingRight: "var(--card-spacing, 16px)",
      ...style
    }
  }, props), children);
}
function CardTitle({
  className = "",
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-title",
    className: className,
    style: {
      fontFamily: "var(--font-heading)",
      fontSize: "var(--text-base)",
      lineHeight: "var(--leading-snug)",
      fontWeight: "var(--weight-medium)",
      ...style
    }
  }, props), children);
}
function CardDescription({
  className = "",
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-description",
    className: className,
    style: {
      fontSize: "var(--text-sm)",
      color: "var(--muted-foreground)",
      ...style
    }
  }, props), children);
}
function CardAction({
  className = "",
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-action",
    className: className,
    style: {
      gridColumn: "2",
      gridRow: "1 / span 2",
      justifySelf: "end",
      alignSelf: "start",
      ...style
    }
  }, props), children);
}
function CardContent({
  className = "",
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-content",
    className: className,
    style: {
      paddingLeft: "var(--card-spacing, 16px)",
      paddingRight: "var(--card-spacing, 16px)",
      ...style
    }
  }, props), children);
}
function CardFooter({
  className = "",
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-footer",
    className: className,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "var(--card-spacing, 16px)",
      borderTop: "1px solid var(--border)",
      background: "color-mix(in oklch, var(--muted), transparent 50%)",
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { Card, CardHeader, CardTitle, CardDescription, CardAction, CardContent, CardFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/card/Card.jsx", error: String((e && e.message) || e) }); }

// components/status/StatusBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * home-srv StatusBadge — a colored dot + uppercase mono label.
 * The instrument-readout way the monitor names service state.
 */

const STATUS_META = {
  online: {
    label: "працює",
    color: "var(--status-online)"
  },
  updating: {
    label: "оновлюється",
    color: "var(--status-updating)"
  },
  down: {
    label: "впав",
    color: "var(--status-down)"
  }
};
function StatusBadge({
  status = "online",
  label,
  className = "",
  style = {},
  ...props
}) {
  const meta = STATUS_META[status] || STATUS_META.online;
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      width: 6,
      height: 6,
      flexShrink: 0,
      borderRadius: "var(--radius-full)",
      background: meta.color
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: meta.color,
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-widest)"
    }
  }, label || meta.label));
}
Object.assign(__ds_scope, { STATUS_META, StatusBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/status/StatusBadge.jsx", error: String((e && e.message) || e) }); }

// components/service/ServiceCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Lucide "rotate-cw" — the restart affordance used across the monitor. */
function RotateCw({
  size = 14,
  spin = false
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": true,
    style: spin ? {
      animation: "hs-spin 1s linear infinite"
    } : undefined
  }, /*#__PURE__*/React.createElement("path", {
    d: "M21 12a9 9 0 1 1-3-6.7L21 8"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M21 3v5h-5"
  }));
}
function formatUptime(total) {
  const days = Math.floor(total / 86400);
  const h = String(Math.floor(total % 86400 / 3600)).padStart(2, "0");
  const m = String(Math.floor(total % 3600 / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  const clock = `${h}:${m}:${s}`;
  return days > 0 ? `${days}д ${clock}` : clock;
}

/**
 * ServiceCard — the signature home-srv row: a status-colored left rail,
 * mono service name + port, a status readout, and a restart control.
 */
function ServiceCard({
  name,
  port,
  status = "online",
  uptime = 0,
  onRestart,
  style = {},
  ...props
}) {
  const meta = __ds_scope.STATUS_META[status] || __ds_scope.STATUS_META.online;
  const railColor = {
    online: "var(--status-online)",
    updating: "var(--status-updating)",
    down: "var(--status-down)"
  }[status];
  return /*#__PURE__*/React.createElement(__ds_scope.Card, _extends({
    style: {
      position: "relative",
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: "absolute",
      top: 0,
      bottom: 0,
      left: 0,
      width: 4,
      background: railColor
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      paddingLeft: 20,
      paddingRight: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      minWidth: 0,
      flex: 1,
      flexDirection: "column",
      gap: 4,
      fontFamily: "var(--font-mono)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-medium)",
      color: "var(--card-foreground)"
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--muted-foreground)"
    }
  }, ":", port)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: "var(--text-xs)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StatusBadge, {
    status: status
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--muted-foreground)",
      fontVariantNumeric: "tabular-nums"
    }
  }, status === "down" ? "uptime —" : `uptime ${formatUptime(uptime)}`))), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: status === "down" ? "outline" : "ghost",
    size: "sm",
    disabled: status === "updating",
    onClick: onRestart,
    "aria-label": `Перезапустити ${name}`,
    style: {
      flexShrink: 0,
      fontFamily: "var(--font-sans)"
    }
  }, /*#__PURE__*/React.createElement(RotateCw, {
    size: 14,
    spin: status === "updating"
  }), "\u0420\u0435\u0441\u0442\u0430\u0440\u0442")));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/service/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/monitor/Monitor.jsx
try { (() => {
/* home-srv monitor — the live dashboard. Composes ServiceCard from the
   design-system bundle. Faithful recreation of the source App.tsx:
   uptime ticks every second; restart flips to "updating" for 4s. */

const {
  ServiceCard
} = window.HomeSrvDesignSystem_e51a33;
const INITIAL = [{
  id: "nextcloud",
  name: "nextcloud",
  port: 8443,
  status: "down",
  uptime: 0
}, {
  id: "qbittorrent",
  name: "qbittorrent",
  port: 8080,
  status: "updating",
  uptime: 0
}, {
  id: "home-assistant",
  name: "home-assistant",
  port: 8123,
  status: "online",
  uptime: 14 * 86400 + 6 * 3600 + 32 * 60 + 41
}, {
  id: "jellyfin",
  name: "jellyfin",
  port: 8096,
  status: "online",
  uptime: 6 * 86400 + 18 * 3600 + 4 * 60 + 12
}, {
  id: "pi-hole",
  name: "pi-hole",
  port: 53,
  status: "online",
  uptime: 32 * 86400 + 11 * 3600 + 47 * 60 + 3
}, {
  id: "wireguard",
  name: "wireguard",
  port: 51820,
  status: "online",
  uptime: 32 * 86400 + 11 * 3600 + 46 * 60 + 58
}, {
  id: "gitea",
  name: "gitea",
  port: 3000,
  status: "online",
  uptime: 2 * 86400 + 3 * 3600 + 15 * 60 + 27
}];
const RESTART_MS = 4000;
function Monitor() {
  const [services, setServices] = React.useState(INITIAL);
  React.useEffect(() => {
    const t = window.setInterval(() => {
      setServices(prev => prev.map(s => s.status === "online" ? {
        ...s,
        uptime: s.uptime + 1
      } : s));
    }, 1000);
    return () => window.clearInterval(t);
  }, []);
  const restart = React.useCallback(id => {
    setServices(prev => prev.map(s => s.id === id ? {
      ...s,
      status: "updating",
      uptime: 0
    } : s));
    window.setTimeout(() => {
      setServices(prev => prev.map(s => s.id === id ? {
        ...s,
        status: "online",
        uptime: 0
      } : s));
    }, RESTART_MS);
  }, []);
  const online = services.filter(s => s.status === "online").length;
  const down = services.filter(s => s.status === "down").length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      minHeight: "100vh",
      justifyContent: "center",
      padding: "32px 16px",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("main", {
    style: {
      display: "flex",
      width: "100%",
      maxWidth: 448,
      flexDirection: "column",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      fontFamily: "var(--font-mono)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 12,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      color: "var(--muted-foreground)"
    }
  }, "home-srv / \u043C\u043E\u043D\u0456\u0442\u043E\u0440"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: "var(--font-sans)",
      fontSize: 24,
      fontWeight: 600,
      letterSpacing: "-0.025em",
      color: "var(--foreground)"
    }
  }, "\u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      fontVariantNumeric: "tabular-nums"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, online, "/", services.length, " \u0443 \u043C\u0435\u0440\u0435\u0436\u0456"), down > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--destructive)"
    }
  }, " \xB7 ", down, " ", down === 1 ? "впав" : "впали"))), /*#__PURE__*/React.createElement("section", {
    "aria-label": "\u0421\u0435\u0440\u0432\u0456\u0441\u0438",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, services.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.id,
    className: "hs-animate-card-enter",
    style: {
      animationDelay: `${i * 70}ms`
    }
  }, /*#__PURE__*/React.createElement(ServiceCard, {
    name: s.name,
    port: s.port,
    status: s.status,
    uptime: s.uptime,
    onRestart: () => restart(s.id)
  }))))));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(Monitor, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/monitor/Monitor.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardTitle = __ds_scope.CardTitle;

__ds_ns.CardDescription = __ds_scope.CardDescription;

__ds_ns.CardAction = __ds_scope.CardAction;

__ds_ns.CardContent = __ds_scope.CardContent;

__ds_ns.CardFooter = __ds_scope.CardFooter;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.STATUS_META = __ds_scope.STATUS_META;

__ds_ns.StatusBadge = __ds_scope.StatusBadge;

})();
