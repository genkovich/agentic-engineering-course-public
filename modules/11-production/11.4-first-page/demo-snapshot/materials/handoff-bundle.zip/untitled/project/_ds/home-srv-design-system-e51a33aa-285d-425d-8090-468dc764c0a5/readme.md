# home-srv — Design System

A dark **technical-monitor** design language for **home-srv**, a status panel
for a self-hosted home server. The whole system is tuned for one job: reading
service state at a glance in a dim room. Deep-indigo canvas, a single magenta
accent, and a color-coded status rail on every service card.

> **Language:** the product UI is in **Ukrainian**. Copy examples below are in
> Ukrainian on purpose — match it.

---

## Sources

This system was reverse-engineered from the attached repository. If you have
access, read it to go deeper:

- **GitHub:** `genkovich/11.8-first-page` — https://github.com/genkovich/11.8-first-page
  - Branch **`main`** — greenfield Vite + React + Tailwind v4 + shadcn/ui (base-nova preset) scaffold.
  - Branch **`generated`** — the *themed* result and the real product screen. This is the ground truth for home-srv: `src/index.css` (theme tokens) and `src/App.tsx` (the monitor).
  - `materials/good-page.png` — reference render of the monitor (copied into this project at `materials/`).

The underlying UI kit is **shadcn/ui base-nova** (`components.json`), icon
library **Lucide**. Component numeric values (radii, paddings, sizes) were
copied from the source, not rounded to a grid.

---

## Index / manifest

**Root**
- `styles.css` — the single entry point consumers link (`@import` manifest only).
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill front-matter for use in Claude Code.

**Tokens** (`tokens/`) — all reachable from `styles.css`
- `fonts.css` — Outfit + Fira Code (Google Fonts).
- `colors.css` — surfaces, magenta primary, status trio, data ramp, light override.
- `typography.css` — families, type scale, weights, tracking.
- `spacing.css` — spacing scale, radius ramp, shadows, the hairline ring.
- `motion.css` — spin + card-enter keyframes.

**Components** (`components/`)
- **Button** (`buttons/`) — primary action control; 6 variants, 7 sizes.
- **Card** (`card/`) — raised surface + sub-parts (Header/Title/Description/Action/Content/Footer).
- **StatusBadge** (`status/`) — dot + uppercase mono state label. *(intentional addition)*
- **ServiceCard** (`service/`) — the signature status-rail service row. *(intentional addition)*

**UI kits** (`ui_kits/`)
- **monitor** (`monitor/`) — the live "Статус сервера" dashboard.

**Guidelines** (`guidelines/`) — foundation specimen cards for the Design System tab (Colors, Type, Spacing, Brand).

### Intentional additions
The source defines only **Button** and **Card**; the status motif is built
inline in `App.tsx`. Because that motif *is* the brand, it is extracted into
two reusable primitives:
- **StatusBadge** — the dot + uppercase label, so state naming is consistent.
- **ServiceCard** — the full rail + readout + restart row, the hallmark surface.

---

## Content fundamentals

- **Language & tone.** Ukrainian, terse, technical, lowercase-friendly. It
  reads like a terminal, not a marketing site.
- **Service names are literal & lowercase**, in mono: `nextcloud`, `home-assistant`,
  `pi-hole`, `wireguard`, `gitea`. Never Title-Case them.
- **Ports** are shown mono, dimmed, with a leading colon: `:8123`, `:51820`.
- **Status verbs** are single Ukrainian words, UPPERCASE with wide tracking:
  `ПРАЦЮЄ` (online), `ОНОВЛЮЄТЬСЯ` (updating), `ВПАВ` (down).
- **Uptime** is a technical readout: `uptime 14д 06:32:44`, or `uptime —` when
  down. Days abbreviated `д`; clock is zero-padded `HH:MM:SS`, tabular-nums.
- **Summaries** are compact and quantified: `5/7 у мережі · 1 впав`. Middot `·`
  separates clauses. Pluralize correctly (`1 впав` / `2 впали`).
- **Eyebrows** use a slash path metaphor: `home-srv / монітор`, uppercase, mono,
  wide tracking, muted.
- **Buttons** are imperative and short: `Рестарт`, `Деталі`.
- **No emoji.** State is carried by colored dots (`●`) and rails, never emoji.
  Unicode control glyphs (`↻`) are acceptable in prose but the UI uses the
  Lucide `rotate-cw` icon.

---

## Visual foundations

- **Mood:** a dark server monitor. Everything sits on a deep desaturated-indigo
  canvas (`--background`, `oklch(0.165 0.035 282)`); cards are one step lighter
  (`--card`). Light mode exists (`.light`) but is not the brand default.
- **Color is meaning.** There is exactly **one brand accent — magenta**
  (`--primary`) — used for primary buttons, focus rings, and chart-1. Everything
  else is either neutral or a **semantic status color**:
  - teal `--status-online` (працює)
  - amber `--status-updating` (оновлюється)
  - red `--status-down` (впав)
  Don't introduce new hues; pull from `--chart-1…5` for data viz.
- **Type:** two families only. **Outfit** for the interface (headings, buttons,
  body); **Fira Code** for every piece of machine data — names, ports, uptime,
  status labels, eyebrows. When in doubt whether something is "data," it's mono.
- **The status rail** is the signature move: a 4px vertical bar flush to the
  left edge of a service card, colored by status. It's the fastest scan target
  on the screen.
- **Cards:** raised surface, radius `--radius-xl` (~11px), a **1px hairline
  ring** (`inset 0 0 0 1px foreground/10`) rather than a heavy drop shadow.
  Shadows exist in the ramp but are used sparingly. Internal padding 16px
  (12px at `size="sm"`).
- **Borders/lines** are low-contrast indigo (`--border`), never pure white.
- **Corner radii:** buttons `--radius-lg` (8px), cards `--radius-xl`, dots/pills
  `--radius-full`.
- **Layout:** a single narrow centered column (`max-width: 448px`), 24px section
  gaps, 12px between cards. Generous vertical breathing room; the screen is
  deliberately calm and un-dense.
- **Motion:** understated. Cards fade + rise 12px on load, staggered 70ms
  (`hs-animate-card-enter`). The restart icon spins while `updating`. Standard
  easing (`ease-out`, ~0.5s). All motion respects `prefers-reduced-motion`.
- **Hover:** buttons lighten (primary → 20% toward transparent; ghost → faint
  muted wash). **Press:** buttons nudge **down 1px** (`translateY(1px)`) — no
  scale. Focus: 3px magenta ring.
- **Transparency & blur:** used lightly via `color-mix` for hover/tint states
  (e.g. `muted` at 50%). No glassmorphism, no backdrop blur.
- **Imagery:** none. home-srv is a data instrument — there are no photos,
  illustrations, gradients, or textures. Keep it that way.

---

## Iconography

- **System:** [Lucide](https://lucide.dev) (the source's `iconLibrary`). In
  React use `lucide-react`; in static HTML load Lucide from CDN
  (`https://unpkg.com/lucide@latest`) or inline the specific path.
- **Style:** 2px stroke, round caps/joins, no fill. Render at **14–16px** inline
  with mono text (button icons at 14px). Icons inherit `currentColor`.
- **Known usage:** `rotate-cw` for the restart action (spins while updating).
  `ServiceCard` inlines this exact Lucide path so the bundle needs no icon dep.
- **Status is not iconographic** — it is a colored **dot** (6px, `--radius-full`)
  plus a mono label, and the card **rail**. Do not swap these for icons.
- **No emoji, no PNG icons.** No brand logo exists in the source, so there is no
  logo asset — render the wordmark `home-srv` in mono (see the Brand cards).

---

## Fonts — substitution note

Outfit and Fira Code are loaded from **Google Fonts** (`tokens/fonts.css`), not
shipped as local binaries. These are the exact families the source uses
(`@fontsource-variable/outfit`, `@fontsource/fira-code`), so this is a delivery
change, not a design substitution. If you need offline/self-hosted binaries,
drop them in `assets/fonts/` and replace the `@import` with local `@font-face`
rules.
